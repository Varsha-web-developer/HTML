import message from "./Modules.js";
        document.getElementById("example").innerHTML=message();